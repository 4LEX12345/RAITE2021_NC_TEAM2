<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CrudController_ship extends CI_Controller {
    public function __construct() {
        parent:: __construct();
        $this->load->model('Crud_model_ship');
    }

    public function index() {
        $data['result'] = $this->Crud_model_ship->getAllData();
		$this->load->view('crudView_ship', $data);
    }

    public function create() {
        $this->Crud_model->createData();
        redirect("CrudController_ship");
    }

    public function edit($id) {
        $data['row'] = $this->Crud_model_ship->getData($id);
        $this->load->view('crudEdit_ship', $data);
    }

    public function update($id) {
        $this->Crud_model_ship->updateData($id);
        redirect("CrudController_ship");
    }

    public function delete($id) {
        $this->Crud_model_ship->deleteData($id);
        redirect("CrudController_ship");
    }
    
}
