<!DOCTYPE html>
<html lang="en">
<head>
  <title>SeaFarer International</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <style type="text/css">

	.jumbotron{
  		background-color: #05eef7;
  		color : white;
  		font-family: 'Raleway', sans-serif;
  	}

  	.flex-container {
  		font-family: "Lucida Console", "Courier New", monospace;
  		margin-top: 20px;
 		 display: flex;
 		 align-items: center;
 		 justify-content: center;
	}

.flex-container > div {
	max-width: 500px;
	width: 100%;
	height: 200px;
 	 background-color: #f1f1f1;
  	margin: 10px;
  	padding: 20px;
  	font-size: 30px;
}
	.people{
		border: none;
	}

	.manage_crew{

		margin-top: 50px;
		width: 100%;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.table{
		width: 75%;
		border: 1px solid black;

	}

	td , th{
		border-left: 1px solid black;		
	}

	.item {

	}
  frame{
    
        width: 500px;
    }
    .frame input{
        padding: 20px;

    }
    .container{
      width:400px;
      Height:90px;
      margin-top: 200px;
      background-color: lightblue;
      padding:20px;
      
    }
  </style>
</head>
<body>

<div class="jumbotron text-center">
  <h1>Seafarer International</h1>
</div>
  
<div class="menu-bar">
  <div class="row">
    <div class="col-sm-4 text-center">
    	<a href="#1">
      <h3>Dashboard</h3>
      </a>
    </div>
    <div class="col-sm-4 text-center">
     <a href="<?php echo site_url('CrudController');?>">
      <h3>Crews</h3>
      </a>

    </div>
    <div class="col-sm-4 text-center">
    <a href="<?php echo site_url('CrudController_ship');?>">
      <h3>Ships</h3>
      </a>        
    </div>
  </div>
</div>

 <div class="body">
 	<div class="flex-container">
  <div id="1" name = "1">
  	<p class="people">
        
          <span class="glyphicon glyphicon-user"></span> Total Crews 
          <h1><a href="<?php echo site_url('Crud_model/getData($id)')?>"></a></h1>
      
      </p> 
  </div>
  <div>
  		<p class="people">
        
          <span class="glyphicon glyphicon-user"></span> Total Ships 
      
      </p>
  </div>
</div>
<div>
<div class="frame">
<form method="POST" action="CrudController/update">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Vessel Name</label>
      <input type="text" class="form-control" id="vessel_name" placeholder="Vessel Name">
    </div>
  </div>
  <div class="form-group col-md-1">
    <label for="inputAddress">Weight</label>
    <input type="text" class="form-control" id="weight" placeholder="Input Weight">
  </div>
  <div class="form-group col-md-1">
    <label for="inputAddress2">Width</label>
    <input type="text" class="form-control" id="width" placeholder="Input Width">
  </div>
  <div class="form-row">
    <div class="form-group col-md-1">
      <label for="inputCity">Speed</label>
      <input type="text" class="form-control" id="inputCity" placeholder="Input Speed">
    </div>
    <div class="form-group col-md-1">
      <label for="inputState">Height</label>
      <input type="text" class="form-control" id="height" placeholder="Input Height">
    </div>
  </div>
  <br>

  </div>
  <button style="margin-top: 10px;" type="submit" class="btn btn-primary">Add</button>
</form>
</div>
</div>
</div>
<?php
   if(isset($_FILES['image'])){
      $errors= array();
      $file_name = $_FILES['image']['name'];
      $file_size =$_FILES['image']['size'];
      $file_tmp =$_FILES['image']['tmp_name'];
      $file_type=$_FILES['image']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));

      $extensions= array("jpeg","jpg","png");

      if(in_array($file_ext,$extensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }

      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }

      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"images/".$file_name);
         echo "Success";
      }else{
         print_r($errors);
      }
   }
?>
<center>
<div class="container">
<form action="" method="POST" enctype="multipart/form-data">
         <input type="file" name="image" />
         <input style="margin-top: 10px;padding: 4px 10px 4px 10px; background-color: gray; border-radius: 2px;" type="submit"/>
      </form>
</div>
</center>
 
 </div>

</body>
</html>
