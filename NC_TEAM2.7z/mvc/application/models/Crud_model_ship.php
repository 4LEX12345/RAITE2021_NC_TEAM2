<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud_model extends CI_Model {
    public function __construct() {
        $this->load->database();
    }

    function createData() {
        $data = array (
            'first_name' => $this->input->post('firstName'),
            'last_name' => $this->input->post('lastName'),
            'position' => $this->input->post('position'),
            'quantity' => $this->input->post('quantity')
            
           
        );
        $this->db->insert('crew', $data);
    }

    function getAllData() {
        $query = $this->db->query('SELECT * FROM crew');
        return $query->result();
    }

    function getData($id) {
        $query = $this->db->query('SELECT * FROM crew WHERE `id` =' .$id);
        return $query->row();
    }

    function updateData($id) {
        $data = array (
            'first_name' => $this->input->post('firstName'),
            'last_name' => $this->input->post('lastName'),
            'position' => $this->input->post('position'),
            'quantity' => $this->input->post('quantity')
            
        );
        $this->db->where('id', $id);
        $this->db->update('crew', $data);
    }

    function deleteData($id) {
        $this->db->where('id', $id);
        $this->db->delete('crew');
    }
}
